package com.geektech;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        // write your code here

        String myNameIs;
        System.out.println("myNameIs");
        int NUMBEROFAGE = 30;
        System.out.println(NUMBEROFAGE);
        String word = "Hero";
        System.out.println(word);
        myNameIs = (NUMBEROFAGE + " " + word);
        System.out.println(myNameIs);

        if (NUMBEROFAGE < 0) {
            System.out.println("i will happy");

        } else if (NUMBEROFAGE > 0) {
            System.out.println("i will not");

        } else {
            System.out.println("midle");
        }


        System.out.println("Ведите ваше имя");
        Scanner nero = new Scanner(System.in);
        String name = nero.nextLine();
        System.out.println("Hello " + name);

    }
}
